let EventModel = require('../models/events');

// Create Event
module.exports.createEvent = async function (req, res, next) {
  try {
    console.log("Creating event:", req.body);
    let newEvent = new EventModel(req.body);
    await newEvent.save();
    res.json({
      success: true,
      message: "Event created successfully.",
      data: newEvent
    });
  } catch (error) {
    console.error(error);
    next(error);
  }
};

// List All Events
module.exports.listEvents = async function (req, res, next) {
  try {
    let events = await EventModel.find().populate('createdBy', 'username email');
    res.json(events);
  } catch (error) {
    console.error(error);
    next(error);
  }
};

// Get Single Event by ID
module.exports.eventById = async function (req, res, next) {
  try {
    let event = await EventModel.findById(req.params.id).populate('createdBy', 'username email');
    if (!event) throw new Error("Event not found");
    res.json(event);
  } catch (error) {
    console.error(error);
    next(error);
  }
};

// Update Event
module.exports.updateEvent = async function (req, res, next) {
  try {
    let updatedEvent = await EventModel.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedEvent) throw new Error("Event not updated. Does it exist?");
    res.json({
      success: true,
      message: "Event updated successfully.",
      data: updatedEvent
    });
  } catch (error) {
    console.error(error);
    next(error);
  }
};

// Delete Event
module.exports.deleteEvent = async function (req, res, next) {
  try {
    let result = await EventModel.deleteOne({ _id: req.params.id });
    if (result.deletedCount === 0) throw new Error("Event not found or already deleted.");
    res.json({
      success: true,
      message: "Event deleted successfully."
    });
  } catch (error) {
    console.error(error);
    next(error);
  }
};

// Delete All Events
module.exports.deleteAllEvents = async function (req, res, next) {
  try {
    let result = await EventModel.deleteMany();
    res.json({
      success: true,
      message: `${result.deletedCount} events deleted successfully.`
    });
  } catch (error) {
    console.error(error);
    next(error);
  }
};