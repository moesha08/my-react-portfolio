const model = require("mongoose");

module.exports.helloWorld = function (req, res, next) {

    res.send('Hello World');
};

module.exports.goodbye = function (req, res, next) {

    res.send('Goodbye');
};

module.exports.home = function(req, res, next){

    let messageObj = {
        message: 'Welcome to our Ticket Management System'
    }
    res.json(messageObj);
};