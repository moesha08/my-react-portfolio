let UserModel = require('../models/users');

module.exports.createUser = async function(req, res, next){

    try {

        console.log("body: " + req.body);

        let newUser = new UserModel(req.body);
        if(req.body.password) {
            newUser.password = req.body.password;  // Trigger virtual setter for password hashing
        }
        await newUser.save();

        console.log(newUser);

        res.json(newUser);  

    } catch (error) {
        console.log(error);
        next(error)
    }
}

module.exports.listUser = async function (req, res, next) {
    try {
        let list = await UserModel.find();

        res.json(list);
    } catch (error) {
        console.log(error);
        next(error);
    }
}

module.exports.userById = async function (req, res, next) {
    try {
        let user = await UserModel.findOne({_id: req.params.id
        });

        res.json(user);
    } catch (error) {
        console.log(error);
        next(error);
    }
}

module.exports.updateUser = async function(req, res, next){
    try {

        console.log("body: " + req.body);

        let user = await UserModel.findById(req.params.id);
        
        if(!user) {
            throw new Error('User not found');
        }

        // Update fields
        if(req.body.firstName) user.firstName = req.body.firstName;
        if(req.body.lastName) user.lastName = req.body.lastName;
        if(req.body.email) user.email = req.body.email;
        if(req.body.username) user.username = req.body.username;
        
        // Handle password update - triggers virtual setter for hashing
        if(req.body.password) {
            user.password = req.body.password;
        }

        let result = await user.save();

        console.log(result);

        if(result){
            res.json({
                success: true,
                message: "User updated successfully.",
                data: result
            });
        } else {
            throw new Error('User not updated. Are you sure it exists')
        }

    } catch (error) {
        console.log(error);
        next(error)
    }
}   

module.exports.deleteUser = async function(req, res, next){
    try {

        let result = await UserModel.deleteOne({_id: req.params.id});

        console.log(result);

        if(result.deletedCount > 0){
            res.json({
            success: true,
            message: "User deleted successfully."
        });
        } else {
            throw new Error('User not deleted. Are you sure it exists')
        }

    } catch (error) {
        console.log(error);
        next(error)
    }
}  

module.exports.deleteAllUsers = async function(req, res, next){
    try {

        let result = await UserModel.deleteMany();

        console.log(result);

        if(result.deletedCount > 0){
            res.json({
            success: true,
            message: "Users deleted successfully."
        });
        } else {
            throw new Error('Users are not deleted. Are you sure it exists')
        }

    } catch (error) {
        console.log(error);
        next(error)
    }
}  