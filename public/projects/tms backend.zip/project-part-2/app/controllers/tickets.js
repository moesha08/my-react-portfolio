const TicketModel = require('../models/tickets');
const UserModel = require('../models/users');

// Helper: generate ticket number based on date
async function generateTicketNumber() {
  const date = new Date();
  const yyyymmdd = date.toISOString().slice(0, 10).replace(/-/g, '');
  const count = await TicketModel.countDocuments({ ticketNumber: { $regex: `^${yyyymmdd}` } });
  const sequence = String(count + 1).padStart(7, '0');
  return `${yyyymmdd}-${sequence}`;
}

// Create Ticket
module.exports.createTicket = async function (req, res, next) {
  try {
    const ticketNumber = await generateTicketNumber();

    const newTicket = new TicketModel({
      ticketNumber: ticketNumber,
      createdBy: req.auth.id, 
      customerName: req.body.customerName,
      customerEmail: req.body.customerEmail,
      priority: req.body.priority,
      description: req.body.description,
      iterations: [
        {
          username: req.auth.username,
          comment: 'Ticket created',
          statusChange: 'NEW'
        }
      ]
    });

    const result = await newTicket.save();
    res.status(201).json(result);
  } catch (error) {
    console.log(error);
    next(error);
  }
};

// LIST Tickets (open by default)
module.exports.listTickets = async function (req, res, next) {
  try {
    const showClosed = req.query.showClosed === 'true';
    let filter = showClosed ? {} : { status: { $ne: 'CLOSED' } };

    let tickets = await TicketModel.find(filter).sort({ createdAt: -1 });
    res.json(tickets);
  } catch (error) {
    console.log(error);
    next(error);
  }
};

// GET ticket by ID
module.exports.ticketById = async function (req, res, next) {
  try {
    const ticket = await TicketModel.findById(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: 'Ticket not found' });
    }
    res.json(ticket);
  } catch (error) {
    console.log(error);
    next(error);
  }
};

// Update Ticket
module.exports.updateTicket = async function (req, res, next) {
  try {
    const ticket = await TicketModel.findById(req.params.id);

    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });

    if (ticket.status === 'CLOSED') {
      return res.status(400).json({ message: 'Cannot modify a closed ticket.' });
    }

    // Update allowed fields
    ticket.description = req.body.description || ticket.description;
    ticket.priority = req.body.priority || ticket.priority;

    const updated = await ticket.save();
    res.json({ success: true, message: 'Ticket updated successfully', data: updated });
  } catch (error) {
    console.log(error);
    next(error);
  }
};

// Change status (Admin)
module.exports.changeStatus = async function (req, res, next) {
  try {
    const { status, comment, username, resolution } = req.body;
    const ticket = await TicketModel.findById(req.params.id);

    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });

    if (ticket.status === 'CLOSED') {
      return res.status(400).json({ message: 'Ticket already closed. No modifications allowed.' });
    }

    if (status === 'CLOSED' && (!resolution || resolution.trim() === '')) {
      return res.status(400).json({ message: 'Resolution is required to close a ticket.' });
    }

    ticket.status = status;
    if (resolution) ticket.resolution = resolution;

    ticket.iterations.push({
      username: username || 'Admin',
      comment: comment || '',
      date: new Date(),
      statusChange: status
    });

    const updated = await ticket.save();
    res.json({ success: true, message: 'Ticket status updated.', data: updated });
  } catch (error) {
    console.log(error);
    next(error);
  }
};

// Delete (Cancel instead of real delete)
module.exports.cancelTicket = async function (req, res, next) {
  try {
    const ticket = await TicketModel.findById(req.params.id);

    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });

    ticket.status = 'CANCELLED';
    ticket.iterations.push({
      username: req.body.username || 'System',
      comment: 'Ticket cancelled',
      date: new Date(),
      statusChange: 'CANCELLED'
    });

    const updated = await ticket.save();
    res.json({ success: true, message: 'Ticket cancelled successfully', data: updated });
  } catch (error) {
    console.log(error);
    next(error);
  }
};

// Delete all (for testing only)
module.exports.deleteAllTickets = async function (req, res, next) {
  try {
    const result = await TicketModel.deleteMany();
    res.json({
      success: true,
      message: `${result.deletedCount} tickets deleted.`
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};