const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let crypto = require('crypto');

const UserSchema = new Schema(
    {
        firstName: String,
        lastName: String,
        
        email: {
            type: String,
            unique: true,
            match: [/.+\@.+\..+/, "Please fill a valid e-mail address"]
        },
        //password: String,
        hashed_password: {
            type: String,
            required: "Password is required"
        },
        salt: {
            type: String,
            default: ''
        },
        username: {
            type: String,
            unique: true,
            required: "Username is required",
            trim: true
        },
        created: {
            type: Date,
            default: Date.now,
            immutable: true
        },
        updated: {
            type: Date,
            default: Date.now
        }
    },
    {
        collection: "users"
    }
);

UserSchema.virtual('fullName')
    .get(function () {
        return this.firstName + " " + this.lastName;
    })
    .set(function (fullName) {
        let splitName = fullName.split(' ');
        this.firstName = splitName[0] || '';
        this.lastName = splitName[1] || '';
    });

UserSchema.methods.hashPassword = function (password){
    if(!this.salt)
        this.salt = crypto.randomBytes(16).toString('base64');
    return crypto.pbkdf2Sync(password, Buffer.from(this.salt, 'base64'), 10000, 64, 'sha512').toString('base64');
}

UserSchema.virtual('password')
    .set(function (password) {
        this.hashed_password = this.hashPassword(password);
    });


UserSchema.methods.authenticate = function (password){
    return this.hashed_password === this.hashPassword(password);
}

UserSchema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function(doc, retu){
        delete retu._id
        delete retu.hashed_password
        delete retu.salt
    }
});

module.exports = mongoose.model('User', UserSchema);