const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const TicketSchema = new Schema(
  {
    ticketNumber: {
      type: String,
      unique: true,
      required: true
    },
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    customerName: {
      type: String,
      required: true
    },
    customerEmail: {
      type: String,
      required: true,
      match: [/.+\@.+\..+/, "Please enter a valid email address"]
    },
    priority: {
      type: String,
      enum: ['Low', 'Medium', 'High', 'Urgent'],
      default: 'Low'
    },
    description: {
      type: String,
      required: true
    },
    status: {
      type: String,
      enum: ['NEW', 'IN_PROGRESS', 'DISPATCHED', 'CLOSED', 'CANCELLED'],
      default: 'NEW'
    },
    resolution: {
      type: String,
      default: ''
    },
    iterations: [
      {
        username: String,
        comment: String,
        date: { type: Date, default: Date.now },
        statusChange: String
      }
    ]
  },
  {
    collection: 'tickets',
    timestamps: true
  }
);

module.exports = mongoose.model('Ticket', TicketSchema);