const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const EventSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true
    },
    description: {
      type: String,
      required: true
    },
    location: {
      type: String,
      required: true
    },
    date: {
      type: Date,
      required: true
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', // link to your user who created the event 
      required: true
    }, 
    status: {
      type: String,
      enum: ['Upcoming', 'Ongoing', 'Completed', 'Cancelled'],
      default: 'Upcoming'
    },
    created: {
      type: Date,
      default: Date.now,
      immutable: true
    },
    updated: {
      type: Date,
      default: Date.now
    }
  },
  {
    collection: 'events'
  }
);

module.exports = mongoose.model('Event', EventSchema);