var express = require('express');
var router = express.Router();

var eventController = require('../controllers/events');

router.post('/', eventController.createEvent);
router.get('/', eventController.listEvents);
router.get('/:id', eventController.eventById);
router.put('/:id', eventController.updateEvent);
router.delete('/:id', eventController.deleteEvent);
router.delete('/', eventController.deleteAllEvents); //For test only REMEMBER!! (EAN)

module.exports = router;