var express = require('express');
var router = express.Router();

var userController = require('../controllers/users');

router.post('/', userController.createUser);
router.get('/', userController.listUser);
router.get('/:id', userController.userById);
router.put('/:id', userController.updateUser);
router.delete('/:id', userController.deleteUser);
router.delete('/', userController.deleteAllUsers);


module.exports = router;