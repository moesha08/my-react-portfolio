var express = require('express');
var router = express.Router();

var ticketController = require('../controllers/tickets');

router.post('/', ticketController.createTicket);
router.get('/', ticketController.listTickets);
router.get('/:id', ticketController.ticketById);
router.put('/:id', ticketController.updateTicket);
router.put('/:id/status', ticketController.changeStatus);
router.put('/:id/cancel', ticketController.cancelTicket);
router.delete('/', ticketController.deleteAllTickets); // test use only

module.exports = router;