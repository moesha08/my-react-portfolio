# Help Desk System - Web Application

A comprehensive Help Desk System built with Express.js and MongoDB, featuring user management, authentication, and authorization using JWT tokens. This is the first release (Part 2) of the COMP229 Web Application Development project.

## Features

- Express 5 with CORS and request logging (morgan)
- MongoDB connection via Mongoose
- User CRUD operations (Create, Read, Update, Delete)
- JWT-based Authentication and Authorization
- Password hashing with salt using PBKDF2
- Simple error handler returning JSON responses
- MVC architecture with clear separation of concerns

## Tech stack

- Node.js, Express 5
- MongoDB, Mongoose
- JWT (JSON Web Tokens) for authentication
- Morgan for logging, CORS for cross-origin requests
- dotenv for environment configuration

## Getting started

### Prerequisites

- Node.js 18+ recommended
- A MongoDB connection string (Atlas or local)

### 1) Clone and install

```bash
git clone https://github.com/Zuck7/project-part-2.git
cd project-part-2
npm install
```

### 2) Configure environment

Create a `.env` file in the project root and set your MongoDB URI and JWT secret:

```env
ATLASDB="your-mongodb-connection-string"
SECRETKEY="your-jwt-secret-key"
```

### 3) Run the server

```bash
npm start
```

The server listens on http://localhost:3000.

To run with auto-restart during development:

```bash
npm install --save-dev nodemon
npx nodemon server.js
```

## Project structure

```
.
├── app
│   ├── controllers
│   │   ├── auth.js       (Authentication logic)
│   │   ├── index.js      (Home/Info endpoints)
│   │   └── users.js      (User CRUD operations)
│   ├── models
│   │   └── users.js      (User schema and authentication methods)
│   └── routers
│       ├── auth.js       (Auth routes)
│       ├── index.js      (Home routes)
│       └── users.js      (User routes)
├── config
│   └── db.js             (MongoDB connection)
├── server.js             (Express app setup)
├── package.json
└── README.md
```

## Configuration

- `config/db.js` reads `process.env.ATLASDB` and connects to MongoDB via Mongoose.
- `server.js` wires middleware and mounts routers under `/api/*` paths.
- `app/controllers/auth.js` handles JWT token generation and validation.
- `app/models/users.js` implements password hashing with salt and authentication methods.

Environment variables:

- `ATLASDB` — MongoDB URI (e.g., from MongoDB Atlas)
- `SECRETKEY` — JWT secret key for token signing and verification

## API

Base URL: `http://localhost:3000`

All endpoints return JSON responses.

### Authentication — `/api/auth`

- `POST /api/auth/signin` — user login (returns JWT token)

**Request body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Authentication successful",
  "token": "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9..."
}
```

### Users — `/api/users`

- `POST /api/users` — create user
- `GET /api/users` — list all users
- `GET /api/users/:id` — get user by ID
- `PUT /api/users/:id` — update user by ID
- `DELETE /api/users/:id` — delete user by ID
- `DELETE /api/users` — delete all users

**Create User - Request body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "username": "johndoe",
  "password": "securepassword123"
}
```

**Update User - Request body:**
```bash
curl -X PUT http://localhost:3000/api/users/<id> \
  -H 'Content-Type: application/json' \
  -d '{"firstName":"Jane","lastName":"Smith"}'
```

### Home — `/`

- `GET /` — home endpoint (returns welcome message)
- `GET /hello` — hello world endpoint
- `GET /goodbye` — goodbye endpoint

## Implementation notes

- Requests are parsed via `express.json()` and `express.urlencoded({ extended: true })`.
- Logging is via `morgan('dev')`.
- CORS is enabled via `cors()`.
- Errors bubble to a centralized JSON error handler.
- Passwords are hashed using PBKDF2 with a random salt before storage.
- JWT tokens are issued upon successful authentication and expire after 20 minutes.
- The `authenticate()` method compares provided passwords with stored hashed passwords.

## User Schema

```javascript
{
  firstName: String,
  lastName: String,
  email: String (unique, validated),
  username: String (unique, required),
  password: String (virtual - triggers hashing),
  hashed_password: String (stored hash),
  salt: String (random salt for password hashing),
  fullName: String (virtual getter/setter),
  created: Date (immutable),
  updated: Date
}
```

## Troubleshooting

- If the server cannot connect to MongoDB, ensure `ATLASDB` is set and valid.
- If authentication fails, ensure `SECRETKEY` is set in `.env`.
- For JWT token validation errors, check that the token is included in the Authorization header.
- Check the server logs for error stack traces.

## License

MIT
